package org.cocos2d.types;

public class CCPointSize {
    public float size;
}
